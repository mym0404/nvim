#pragma version(1)
#pragma rs_fp_relaxed
#pragma rs java_package_name(${PACKAGE_NAME})

rs_allocation inImage;
int inWidth;
int inHeight;

uchar4 RS_KERNEL flip_horizontally (uint32_t x, uint32_t y) {
    uint32_t inX = inWidth - 1 - x;
    uint32_t inY = y;

    const uchar4 *out = rsGetElementAt(inImage, inX, inY);
    return *out;
}

